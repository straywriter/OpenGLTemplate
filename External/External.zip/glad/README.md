# glad with cmake

this project's purpose is to make build glad as static library with cmake

## Build Option

```
GLAD_BUILD_SHARED   Build glad to shared and set definitions for dll export
```

